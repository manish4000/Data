<?php

namespace App\Models\company;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CompanyContactPersonDetails extends Model
{
    use HasFactory;
    protected $table = 'company_contact_person_details';
    
}
