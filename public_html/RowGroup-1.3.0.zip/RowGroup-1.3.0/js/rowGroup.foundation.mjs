/*! Foundation styling wrapper for RowGroup
 * © SpryMedia Ltd - datatables.net/license
 */

import $ from 'jquery';
import DataTable from 'datatables.net-zf';
import 'datatables.net-rowgroup';




export default DataTable;
