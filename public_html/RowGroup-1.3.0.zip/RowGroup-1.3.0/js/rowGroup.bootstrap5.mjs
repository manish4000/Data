/*! Bootstrap 5 styling wrapper for RowGroup
 * © SpryMedia Ltd - datatables.net/license
 */

import $ from 'jquery';
import DataTable from 'datatables.net-bs5';
import 'datatables.net-rowgroup';




export default DataTable;
