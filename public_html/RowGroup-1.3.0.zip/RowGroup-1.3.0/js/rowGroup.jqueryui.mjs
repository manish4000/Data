/*! jQuery UI styling wrapper for RowGroup
 * © SpryMedia Ltd - datatables.net/license
 */

import $ from 'jquery';
import DataTable from 'datatables.net-ju';
import 'datatables.net-rowgroup';




export default DataTable;
